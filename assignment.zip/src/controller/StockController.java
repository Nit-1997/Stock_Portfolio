package controller;

/**
 * Main controller interface.
 */
public interface StockController {

  /**
   * Starter for the application.
   */
  void start();

}
